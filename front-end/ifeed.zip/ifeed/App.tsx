import React from 'react';
import { StyleSheet } from 'react-native';

import IfeedScreen from './src/components/IfeedScreen.js'
import CadastroScreen from './src/components/CadastroScreen.js'
import LoginScreen from './src/components/LoginScreen.js'
import InstituicoesScreen from './src/components/InstituicoesScreen.js';
import AmigosBemScreen from './src/components/AmigosBemScreen.js';
import BancoAlimentosScreen from './src/components/BancoAlimentosScreen.js';
import AmparaiScreen from './src/components/AmparaiScreen.js';
import IpredeScreen from './src/components/IpredeScreen.js';
import BrasilSemFomeScreen from './src/components/BrasilSemFomeScreen.js';
import CaritasScreen from './src/components/CaritasScreen.js';

import DoarScreen from './src/components/DoarScreen.js';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

const App = () => {

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="IfeedScreen" component={IfeedScreen} options={{headerShown: false}}/>
        <Stack.Screen name="CadastroScreen" component={CadastroScreen} options={{headerShown: false}}/>
        <Stack.Screen name="LoginScreen" component={LoginScreen} options={{headerShown: false}}/>
        <Stack.Screen name="InstituicoesScreen" component={InstituicoesScreen} options={{headerShown: false}}/>
        <Stack.Screen name="AmigosBemScreen" component={AmigosBemScreen} options={{headerShown: false}}/>
        <Stack.Screen name="BancoAlimentosScreen" component={BancoAlimentosScreen} options={{headerShown: false}}/>
        <Stack.Screen name="BrasilSemFomeScreen" component={BrasilSemFomeScreen} options={{headerShown: false}}/>
        <Stack.Screen name="IpredeScreen" component={IpredeScreen} options={{headerShown: false}}/>
        <Stack.Screen name="AmparaiScreen" component={AmparaiScreen} options={{headerShown: false}}/>
        <Stack.Screen name="CaritasScreen" component={CaritasScreen} options={{headerShown: false}}/>
        <Stack.Screen name="DoarScreen" component={DoarScreen} options={{headerShown: false}}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
