import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from '../styles/StyleAmparai.js';
import axios from "axios";

const AmparaiScreen = () => {
    const navigation = useNavigation();

    const [data, setData] = useState(null);

    useEffect(() => {
      fetchData();
    }, []);
  
    const fetchData = async () => {
      try {
        const response = await axios.get('http://10.0.2.2:8080/api/instituicao/1');
        const data = response.data;
        console.log(response.data);
        setData(data);
      } catch (error) {
        console.error(error);
      }
    };

    const handleVoltarInicio = () => {
        navigation.navigate('InstituicoesScreen');
      };
    const handleQueroDoar = () => {
      navigation.navigate('DoarScreen')
    }

  return (
    <View style={styles.container}>
        <Image source={require('../assets/banner-amparai.png')} style={styles.banner} />
        <TouchableOpacity onPress={handleVoltarInicio}>
            <Image source={require('../assets/setabranca.png')}  style={styles.setaBranca} />
        </TouchableOpacity>

      <Text style={styles.nomeInstituicao}>{data ? data.nome : ''}</Text>

      <Text style={styles.sedeInstituicao}>{data ? data.endereco : ''}</Text>

      <View style={styles.sobre}>
        <View style={styles.caixaSobre}>
          <Text style={styles.descricao}>
            {data ? data.descricao : ''}
          </Text>
        </View>
      </View>

      <TouchableOpacity onPress={handleQueroDoar} style={styles.botaoDoar}>
        <View style={styles.botaoDoarCaixa}>
          <Text style={styles.queroDoar}>Quero Doar</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default AmparaiScreen;
