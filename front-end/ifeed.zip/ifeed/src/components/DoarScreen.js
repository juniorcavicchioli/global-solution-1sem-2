import React, { useState } from 'react';
import { View, Text, Image, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const DoarScreen = () => {
  const navigation = useNavigation();

  const [valor, setValor] = useState('R$ 00,00');

  const handleVoltarInicio = () => {
    navigation.navigate('InstituicoesScreen');
  };
  const handleValorChange = (text) => {
    const numericValue = text.replace(/[^0-9]/g, '');
    setValor(numericValue);
  };

  return (
    <View style={styles.container}>
        <View style={styles.botaoFeed}>
          <Text style={styles.feed}>Feed</Text>
        </View>
      <View style={styles.valorBox}>
      <TextInput
          style={styles.valorTexto}
          value={valor}
          onChangeText={handleValorChange}
          keyboardType="numeric"
        />
      </View>
      <View style={styles.titulo}>
        <View style={styles.tituloBox}>
        <TouchableOpacity onPress={handleVoltarInicio}>
            <Image source={require('../assets/setabranca.png')}  style={styles.setaVoltar} />
        </TouchableOpacity>
          <Text style={styles.textoDoacao}>DOAÇÃO</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  botaoFeed: {
    position: 'absolute',
    width: 150,
    height: 150,
    left: 120,
    bottom: 130,
    borderRadius: 360,
    backgroundColor: '#31B7B4',
  },
  feed: {
    position: 'absolute',
    width: 90,
    height: 80,
    left: 30,
    bottom: 10,
    fontFamily: 'Inter',
    fontStyle: 'normal',
    fontWeight: '700',
    fontSize: 30,
    lineHeight: 29,
    alignItems: 'center',
    textAlign: 'center',
    color: '#FFFFFF',
  },
  valorBox: {
    position: 'absolute',
    width: 230,
    height: 110,
    left: 35,
    top: 110,
  },
  valorTexto: {
    width: 230,
    height: 110,
    left: 40,
    top: 110,
    fontFamily: 'Inter',
    fontStyle: 'normal',
    fontWeight: '700',
    fontSize: 50,
    alignItems: 'center',
    textAlign: 'center',
    color: '#000000',
  },
  titulo: {
    width: 300,
    height: 80,
    left: 0,
    top: 0,
  },
  tituloBox: {
    width: 450,
    height: 80,
    left: 0,
    top: 0,
    backgroundColor: '#31B7B4',
  },
  setaVoltar: {
    position: 'absolute',
    width: 50,
    height: 50,
    left: 20,
    top: 15,
    backgroundColor: 'transparent',
  },
  textoDoacao: {
    width: 180,
    height: 40,
    left: 110,
    top: 25,
    fontFamily: 'Inter',
    fontStyle: 'normal',
    fontWeight: '700',
    fontSize: 24,
    alignItems: 'center',
    textAlign: 'center',
    color: '#FFFFFF',
  },
});

export default DoarScreen;
