import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, TextInput, Modal } from 'react-native';
import styles from '../styles/StyleCadastro.js';
import popupStyles from '../styles/StylePopup.js' ;
import axios from "axios";
import { useNavigation } from '@react-navigation/native';


const CadastroScreen = () => {
  const navigation = useNavigation();
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const [telefone, setTelefone] = useState('');
  const [popupMessage, setPopupMessage] = useState('');
  const [showPopup, setShowPopup] = useState(false);

  const handleVoltarInicio = () => {
    navigation.navigate('IfeedScreen');
  };

  const handleClosePopup = () => {
    setShowPopup(false);
    navigation.navigate('IfeedScreen');
  };


  const handleCriar = async () => {
    const data = {
      nome: nome,
      email: email,
      senha: senha,
      telefone: telefone
    };
    try {
      const response = await axios.post('http://10.0.2.2:8080/api/usuario/registrar', data, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      console.log(response.data);
      if (response.status === 201) {
        setPopupMessage('Cadastro realizado com sucesso!');
      } else {
        setPopupMessage('Cadastro não concluído');
      }
      setShowPopup(true);
    } catch (error) {
      console.error(error);
    }
  };


  return(
    <View style={styles.container}>
        <View style={styles.titulo}>
          <TouchableOpacity onPress={handleVoltarInicio} style={styles.arrowContainer}>
            <Image source={require('../assets/setabranca.png')}  style={styles.setabranca} />
          </TouchableOpacity>
          <Text style={styles.tituloTexto}>CADASTRO</Text>
        </View>
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={nome}
            onChangeText={text => setNome(text)}
            placeholder="nome"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
          />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={email}
            onChangeText={text => setEmail(text)}
            placeholder="email"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
          />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={senha}
            onChangeText={text => setSenha(text)}
            placeholder="senha"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
            secureTextEntry={true}
          />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={confirmarSenha}
            onChangeText={text => setConfirmarSenha(text)}
            placeholder="confirmar senha"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
            secureTextEntry={true}
          />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={telefone}
            onChangeText={text => setTelefone(text)}
            placeholder="telefone"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
          />
        </View>
        <TouchableOpacity onPress={handleCriar} style={styles.criarBotao}>
          <Text style={styles.criarTexto}>Criar</Text>
        </TouchableOpacity>

        <Modal visible={showPopup} animationType="slide" transparent>
        <View style={popupStyles.popupContainer}>
          <Text style={popupStyles.popupText}>{popupMessage}</Text>
          <TouchableOpacity onPress={handleClosePopup} style={popupStyles.popupButton}>
            <Text style={popupStyles.popupButtonText}>Fechar</Text>
          </TouchableOpacity>
        </View>
      </Modal>

    </View>
  );
};

export default CadastroScreen;