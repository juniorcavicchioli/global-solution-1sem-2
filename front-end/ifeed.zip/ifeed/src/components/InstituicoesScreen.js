import React, { useState } from 'react';
import { View, Image, Text, TouchableOpacity, ScrollView, TextInput } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import styles from '../styles/StyleInstituicoes.js';

const InstituicoesScreen = () => {
    const navigation = useNavigation();
    const [searchValue, setSearchValue] = useState('');

    const handleBancoAlimentos = () => {
        navigation.navigate('BancoAlimentosScreen');
      };
    const handleAmigosBem = () => {
      navigation.navigate('AmigosBemScreen');
    };
    const handleBrasilSemFome = () => {
      navigation.navigate('BrasilSemFomeScreen');
    };
    const handleCaritas = () => {
      navigation.navigate('CaritasScreen');
    };
    const handleAmparai = () => {
      navigation.navigate('AmparaiScreen');
    };
    const handleIprede = () => {
      navigation.navigate('IpredeScreen');
    };

    const handleSearch = () => {
        const filtered = institutions.filter((institution) =>
            institution.name.toLowerCase().includes(searchValue.toLowerCase())
        );
        setFilteredInstitutions(filtered);
    };
    
  return (
    <ScrollView style={styles.container}>
        <View style={styles.searchBox} />
        <TextInput
          style={styles.searchInput}
          placeholder="pesquisar"
          value={searchValue}
          onChangeText={setSearchValue}
          onSubmitEditing={handleSearch}
        />
        <Image source={require('../assets/searchgreen.png')} onPress={handleSearch} style={styles.searchIcon} />

      <View style={styles.institution}>
        <TouchableOpacity onPress={handleBancoAlimentos} style={styles.institutionBox}>
          <View style={styles.recommendedBox}>
            <Text style={styles.recommendedText}>RECOMENDADO</Text>
          </View>
          <View style={styles.logoBox}>
            <Image source={require('../assets/banco_alimentos.png')} style={styles.logo} />
          </View>
          <View style={styles.nameBox}>
          
            <Text style={styles.nameText}>ONG Banco de Alimentos</Text>
          </View>
          <View style={styles.locationBox}>
            <Text style={styles.locationText}>São Paulo - SP</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.institution}>
        <TouchableOpacity onPress={handleAmparai} style={styles.institutionBox}>
          <View style={styles.logoBox}>
            <Image source={require('../assets/misturai.png')} style={styles.logo} />
          </View>
          <View style={styles.nameBox}>
          
            <Text style={styles.nameText}>Amparaí</Text>
          </View>
          <View style={styles.locationBox}>
            <Text style={styles.locationText}>Porto Alegre - RS</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.institution}>
        <TouchableOpacity onPress={handleIprede} style={styles.institutionBox}>
          <View style={styles.logoBox}>
            <Image source={require('../assets/IPREDE.png')} style={styles.logo} />
          </View>
          <View style={styles.nameBox}>
          
            <Text style={styles.nameText}>IPREDE</Text>
          </View>
          <View style={styles.locationBox}>
            <Text style={styles.locationText}>Fortaleza - CE</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.institution}>
        <TouchableOpacity onPress={handleBrasilSemFome} style={styles.institutionBox}>
          <View style={styles.logoBox}>
            <Image source={require('../assets/brasil_sem_fome.png')} style={styles.logo} />
          </View>
          <View style={styles.nameBox}>
          
            <Text style={styles.nameText}>Brasil Sem Fome</Text>
          </View>
          <View style={styles.locationBox}>
            <Text style={styles.locationText}>Rio de Janeiro - RJ</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.institution}>
        <TouchableOpacity onPress={handleCaritas} style={styles.institutionBox}>
          <View style={styles.logoBox}>
            <Image source={require('../assets/caritas.png')} style={styles.logo} />
          </View>
          <View style={styles.nameBox}>
          
            <Text style={styles.nameText}>Caritas</Text>
          </View>
          <View style={styles.locationBox}>
            <Text style={styles.locationText}>Manaus - AM</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.institution}>
        <TouchableOpacity onPress={handleAmigosBem} style={styles.institutionBox}>
          <View style={styles.logoBox}>
            <Image source={require('../assets/Amigos-do-bem.png')} style={styles.logo} />
          </View>
          <View style={styles.nameBox}>
          
            <Text style={styles.nameText}>Amigos do Bem</Text>
          </View>
          <View style={styles.locationBox}>
            <Text style={styles.locationText}>Caruaru - PE</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.emptySpace}></View>
      
    </ScrollView>
  );
};



export default InstituicoesScreen;
