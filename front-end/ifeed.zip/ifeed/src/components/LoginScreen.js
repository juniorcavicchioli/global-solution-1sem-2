import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, TextInput } from 'react-native';
import styles from '../styles/StyleLogin.js';
import axios from "axios";
import { useNavigation } from '@react-navigation/native';


const LoginScreen = () => {
  const navigation = useNavigation();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  const handleVoltarInicio = () => {
    navigation.navigate('IfeedScreen');
  };
  const handleCadastroConta = () => {
    navigation.navigate('CadastroScreen');
  }

  const handleLogarAnonimo = () => {
    navigation.navigate('InstituicoesScreen');
  }

  const handleLogar = async () => {
    const data = {
      email: email,
      senha: senha
    };
    try {
      const response = await axios.post('http://10.0.2.2:8080/api/usuario/login', data, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      console.log(response.data);
      if (response.status === 200) {
        navigation.navigate('InstituicoesScreen');
      }
      navigation.navigate('InstituicoesScreen'); // SOMENTE PARA SER AUTOMÁTICO O LOGIN
    } catch (error) {
      console.error(error);
    }
    
  }

  

  return(
    <View style={styles.container}>
        <View style={styles.titulo}>
          <TouchableOpacity onPress={handleVoltarInicio} style={styles.arrowContainer}>
            <Image source={require('../assets/setabranca.png')}  style={styles.setabranca} />
          </TouchableOpacity>
          <Text style={styles.tituloTexto}>LOGIN</Text>
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={email}
            onChangeText={text => setEmail(text)}
            placeholder="email"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
          />
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.inputField}
            value={senha}
            onChangeText={text => setSenha(text)}
            placeholder="senha"
            placeholderTextColor="rgba(75, 166, 157, 0.5)"
            secureTextEntry={true}
          />
        </View>
        <TouchableOpacity onPress={handleLogar} style={styles.entrarBotao}>
          <Text style={styles.entrarTexto}>Entrar</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleCadastroConta} style={styles.naoPossuiContaBotao}>
          <Text style={styles.naoPossuiContaTexto}>não possui uma conta?</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleLogarAnonimo} style={styles.naoPossuiContaBotao}>
          <Text style={styles.naoPossuiContaTexto}>LOGIN DIRETO</Text>
        </TouchableOpacity>

    </View>
  );
};

export default LoginScreen;