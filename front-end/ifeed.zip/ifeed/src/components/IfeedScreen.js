import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';
import styles from '../styles/StyleIfeed.js';

import { useNavigation } from '@react-navigation/native';

const IfeedScreen = () => {

    const navigation = useNavigation();

    const handleCadastroPress = () => {
        navigation.navigate('CadastroScreen');
      };

      const handleLoginPress = () => {
        navigation.navigate('LoginScreen');
      };
  return (
    <View style={styles.container}>
        <View style={styles.imageContainer}>
            <Image source={require('../assets/ifeed2.png')} style={styles.ifeed2} />
        </View>
      <TouchableOpacity onPress={handleCadastroPress} style={styles.cadastroBotao}>
        <Text style={styles.cadastroTexto}>CADASTRE-SE</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={handleLoginPress} style={styles.loginBotao}>
        <Text style={styles.loginTexto}>LOGIN</Text>
      </TouchableOpacity>
    </View>
  );
};

export default IfeedScreen;