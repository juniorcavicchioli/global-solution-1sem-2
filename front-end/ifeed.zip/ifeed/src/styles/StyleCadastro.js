import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#FFFFFF',
    },
    titulo: {
      position: 'relative',
      width: '100%',
      height: 80,
      backgroundColor: '#31B7B4',
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 30,
    },
    arrowContainer: {
      position: 'absolute',
      top: 5,
      left: 5,
    },
    setabranca: {
      position: 'absolute',
      width: 50,
      height: 50,
      left: 20,
      top: 13,
    },
    tituloTexto: {
      fontFamily: 'Inter',
      fontStyle: 'normal',
      fontWeight: '700',
      fontSize: 25,
      lineHeight: 60,
      color: '#FFFFFF',
    },
    
    inputContainer: {
      paddingHorizontal: 25,
      justifyContent: 'center',
      marginBottom: 25,
    },
    inputField: {
      width: 340,
      height: 40,
      borderWidth: 2,
      borderColor: '#4BA69D',
      borderRadius: 5,
      justifyContent: 'center',
    },
    labelTexto: {
      fontFamily: 'Inter',
      fontStyle: 'normal',
      fontWeight: '700',
      fontSize: 14,
      lineHeight: 17,
      display: 'flex',
      alignItems: 'center',
      color: 'rgba(75, 166, 157, 0.5)',
    },
    criarBotao: {
      width: 250,
      height: 40,
      backgroundColor: '#31B7B4',
      borderRadius: 10,
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 150,
      alignSelf: 'center',
    },
    criarTexto: {
      fontFamily: 'Inter',
      fontStyle: 'normal',
      fontWeight: '700',
      fontSize: 20,
      lineHeight: 19,
      display: 'flex',
      alignItems: 'center',
      textAlign: 'center',
      color: '#FFFFFF',
    },
  });

export default styles;