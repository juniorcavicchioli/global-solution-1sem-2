import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    popupContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'white',
        padding: 20,
      },
      popupText: {
        fontSize: 18,
        marginBottom: 20,
      },
      popupButton: {
        backgroundColor: 'blue',
        padding: 10,
        borderRadius: 5,
      },
      popupButtonText: {
        color: 'white',
        fontSize: 16,
      },
});

export default styles;