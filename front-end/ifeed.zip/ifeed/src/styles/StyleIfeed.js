import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#FFFFFF',
    },
    imageContainer: {
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 40,
    },
    ifeed2: {
      width: 350,
      height: 350,
      resizeMode: 'contain',
    },
    cadastroBotao: {
      width: '70%',
      height: 40,
      alignSelf: 'center',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 20,
      backgroundColor: '#31B7B4',
      borderRadius: 10,
    },
    cadastroTexto: {
      fontFamily: 'Inter',
      fontStyle: 'normal',
      fontWeight: '700',
      fontSize: 18,
      lineHeight: 22,
      color: '#FFFFFF',
    },
    loginBotao: {
      width: '70%',
      height: 40,
      alignSelf: 'center',
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 20,
    },
    loginTexto: {
      fontFamily: 'Inter',
      fontStyle: 'normal',
      fontWeight: '700',
      fontSize: 18,
      lineHeight: 22,
      color: '#31B7B4',
    },
  });

export default styles;